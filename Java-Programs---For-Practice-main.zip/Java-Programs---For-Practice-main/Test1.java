package com.test.Basic_Java_Programs;

public class Test1 
{
	
//Main Method : Every Program Execution Starts from Main Method
	public static void main(String[] args) 
	{
		//For Printing Statement we make use of "System.out.print();"
		System.out.println("Hello World");
	}

}

/* OUTPUT :


    Hello World

*/



