package com.test.Basic_Java_Programs;

public class Test14__A_to_Z_programs 
{
	public static void main(String[] args) 
	{
		for (char i = 'A'; i <= 'Z'; i++) 
		{
			System.out.print(i + " ");
			
		}
		
	}

}


/*  Output:

A B C D E F G H I J K L M N O P Q R S T U V W X Y Z 


*/