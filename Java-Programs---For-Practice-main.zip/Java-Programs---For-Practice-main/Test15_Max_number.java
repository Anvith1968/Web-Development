// Maximum number between two Numbers
package com.test.Basic_Java_Programs;

public class Test15_Max_number 
{
	public static void main(String[] args) 
	{
		int a = 10, b = 20;
		
		if (a > b) 
		{
			System.out.println(a);
		} 
		else 
		{
			System.out.println(b);
		}
		
	}

}


/* Output:
 
20

*/