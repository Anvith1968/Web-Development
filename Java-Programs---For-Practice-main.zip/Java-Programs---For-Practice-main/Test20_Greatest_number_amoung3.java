package com.test.Basic_Java_Programs;

public class Test20_Greatest_number_amoung3 
{
	public static void main(String[] args) 
	{
		int a=10, b=50, c= 30;
		
		if (a>b) 
		{
			if (a>c) 
			{
				System.out.println(a);
				
			}
			else 
			{
				System.out.println(c);
				
			}
			
		}
		else 
		{
			if (b>c) 
			{
				System.out.println(b);
				
			} 
			else 
			{
				System.out.println(c);

			}
			
		}
	}

}


/* Output:
 * 
 * 			
 * 	50
 * 
 */
