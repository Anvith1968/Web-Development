package com.test.Basic_Java_Programs;

public class Test2_Adding_2Number 
{
	public static void main(String[] args) 
	{
		int a = 10;
		int b = 20;
		
		int c = a + b;
		
		System.out.println("Sum of two Number is " + c);
		
	}

}

/* Output :

  30


*/
